using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    [SerializeField] private GameObject Win;
    [SerializeField] private GameObject Lose;
    [SerializeField] private GameObject Pause;

    public void LoadMenu()
    {
        SceneManager.LoadScene(0);
    }

    public void LoadGame1()
    {
        SceneManager.LoadScene(1);
        Time.timeScale = 1;
    }
    public void LoadGame2()
    {
        SceneManager.LoadScene(2);
        Time.timeScale = 1;
    }
    public void LoadGame3()
    {
        SceneManager.LoadScene(3);
        Time.timeScale = 1;
    }
    public void LoadNextGame()
    {
        int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
        if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextSceneIndex);
            Time.timeScale = 1;
        }
        else
        {
            Debug.LogWarning("��������� ����� �� ������� � Build Settings!");
        }
    }


    public void LoadGameRetry()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;
    }


    public void ExitGame()
    {
        Debug.Log("���� ���������");
        Application.Quit();
    }

    public void PauseOn()
    {
        Pause.SetActive(true);
        Time.timeScale = 0;
    }

    public void PauseOff()
    {
        Pause.SetActive(false);
        Time.timeScale = 1;
    }

    public void LoseOn()
    {
        Lose.SetActive(true);
        Time.timeScale = 0;
    }

    
}
