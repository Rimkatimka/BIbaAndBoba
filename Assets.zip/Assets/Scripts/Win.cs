using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinTrue : MonoBehaviour
{
    [SerializeField] private GameObject Win;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="collision"></param>
    void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Player1")
        {
            if (collision.gameObject.tag == "Player2")
            {
                Win.SetActive(true);
                Time.timeScale = 0;
            }
        }
    }
}
