using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player2 : MonoBehaviour
{
    [SerializeField] private GameObject win;
    public int count;
    public float speed1;
    public float jumpForce1;
    public Rigidbody2D rb1;
    public bool CanJump1;
    public int NowHP;
    [SerializeField] private GameObject Lose;
    [SerializeField] Text TextScore;
    [SerializeField] Text TextHP;


    // Start is called before the first frame update
    void Start()
    {
        rb1 = GetComponent<Rigidbody2D>();
        NowHP = 3;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.L))
        {
            rb1.velocity = new Vector2(speed1, rb1.velocity.y);
        }
        if (Input.GetKey(KeyCode.J))
        {
            rb1.velocity = new Vector2(- speed1, rb1.velocity.y);

        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            if (CanJump1 == true)
            {
                rb1.AddForce(transform.up * jumpForce1, ForceMode2D.Impulse);
                CanJump1 = false;
            }
        }
        if (NowHP <= 0)
        {
            Lose.SetActive(true);
            Time.timeScale = 0;
        }
        // �������� �� null ����� ��������������
        if (TextScore != null)
            TextScore.text = count.ToString(); // ����� "" +, ��� ��� ToString() � ��� ���������� ������
        else
            Debug.LogError("TextScore �� �������� � Inspector!");

        if (TextHP != null)
            TextHP.text = NowHP.ToString();
        else
            Debug.LogError("TextHP �� �������� � Inspector!");
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="collision"></param>
    void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Stars2")
        {
            if (count == 3)
            {
                Destroy(collision.gameObject);
                win.SetActive(true);
                Time.timeScale = 0;
            }
            else
            {
                Destroy(collision.gameObject);
                count++;
            }
        }

        if ((collision.gameObject.tag == "Wall") || (collision.gameObject.tag == "Floor") || (collision.gameObject.tag == "Player1"))
        {
            CanJump1 = true;
        }

        if (collision.gameObject.tag == "Enemy")
        {
            NowHP = NowHP - 1;
            Destroy(collision.gameObject);
        }
    }

}