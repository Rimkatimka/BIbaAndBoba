using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player1 : MonoBehaviour
{
    [SerializeField] public GameObject Win;
    public int count;
    public float speed;
    public float jumpForce;
    public Rigidbody2D rb;
    public bool CanJump;
    public int NowHP;
    [SerializeField] private GameObject Lose;
    [SerializeField] Text TextScore;
    [SerializeField] Text TextHP;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        NowHP = 3;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.D))
        {
            rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        if (Input.GetKey(KeyCode.A))
        {
            rb.velocity = new Vector2(-speed, rb.velocity.y);

        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            if (CanJump == true)
            {
                rb.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);
                CanJump = false;
            }
        }
        if (NowHP <= 0)
        {
            Lose.SetActive(true);
            Time.timeScale = 0;
        }
        TextScore.text = "" + count.ToString();
        TextHP.text = "" + NowHP.ToString();

    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="collision"></param>
    void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Stars1")
        {
            if (count == 3)
            {
                Destroy(collision.gameObject);
                Win.SetActive(true);
                Time.timeScale = 0;
            }
            else 
            {
                Destroy(collision.gameObject);
                count++;
            }
        }

        if ((collision.gameObject.tag == "Wall") || (collision.gameObject.tag == "Floor") || (collision.gameObject.tag == "Player2"))
        {
            CanJump = true;
        }

        if (collision.gameObject.tag == "Enemy")
        {
            NowHP = NowHP - 1;
            Destroy(collision.gameObject);
        }
    }

}
